[v25]

       ORM2_Draw2: a new ORM Visio stencil and template
       ================================================

This Visio stencil for ORM diagrams is an updating and upgrading of the ORM2_Draw Visio stencil, which itself resulted from ORM stencil development by various people, including Peter Ritson, Terry Halpin, and Andy Carver. It is an updating, in that it updates (for Visio 11, 12, and ff.) the Table shape, and includes the deontic constraints and value-comparison constraints. It is an upgrading in that it adds built-in shadowing (for fact types and object types), built-in text-arrows (for fact types), built-in constraint-connectors, and some adjustable-arity fact types, as well as several other, later upgrades.

Version 1's stencil (.vss) and template (.vst) files were created, based on ORM2_Draw, during the Winter of 2008-9, by Andy Carver with the help and supervision of Dr. Terry Halpin. Later versions (see below) have added advanced features such as objectification of a fact type. The files have been tested and used pretty extensively in both Visio 10 and Visio 12 (2007), and have been used some in Visio 2010 and Visio 2013. Although we have not tested them extensively using Visio 11 (2003), we assume that the below comments will prove applicable for use with that version as well. Instructions for use with Visio 2010, and installation notes for all versions, are also included below.


Table of contents:
-----------------

- Revision history
- Installation notes
- How to use the new features
- Some unavoidable anomalies, and work-arounds for them
- Some additional and/or more-technical notes


Revision history:
-----------------

Version 25 adds these features:
	- all solution files are included in both the older, Visio 2002 file-format, and the later, Visio 2003-2010 file-format:
		thus, anyone still using Visio 2002 can utilize the above new features, but those using Visio 2013 or later can resolve some format-compatibility issues that arose with using the 2002 format. Workarounds for using the older-format diagrams with later versions, and particularly with 2013 or later, appear below, at the end of the subsection "Using Visio 10 diagrams in Visio 11 and later, and vice versa";
	- you have the option of running the object-type-checking and shadow-setting macro on only the "model" of the current page, rather than necessarily including object-type shapes from ALL the current diagram-file's pages;
	- there is rolename support built into the fact type shapes (except unaries) -- i.e., direct adding of auxiliary text to a fact-type rolebox: this puts the text into correct rolename font-color automatically, and keeps the text together with the rolebox when moving or rotating the shape

Version 24 adds to each constraint shape a context-menu item to change the shape from "Asserted" to "Derived" or vice versa. The "Derived" setting changes the color of the constraint shape to a green (RGB(0,147,66)) chosen by Terry Halpin to represent derived constraints. Version 24 also gives the ability to color the constraint shape any color you like, thru the Format menu; but also, to restore its original color-functionality by simply changing the shape from "Asserted" to "Derived" or vice versa.
Version 23 adds the inequality value-comparison constraint.

Version 22 adds three more-or-less recent enhancements to ORM2 uniqueness-constraint shapes; they are accessible via each shape's context menu: 1) "partial" preferred-identifier uniqueness constraint, for optional use on "part" of a disjunctive reference scheme that has an exclusion constraint between two or more of its optional components (see Dr. Halpin's and Matt Curland's 2013 ORM Workshop paper, "Recent Enhancements to ORM"); 2) for external uniqueness constraints, the join semantics can be set to inner join, outer join, or mixed (i.e., both inner and outer joins: see Dr. Halpin's EMMSAD 2013 paper "Modeling of Reference Schemes"); and 3) use of the external U.C. with a dot in the center, to signify "unique-and-mandatory-where-true" (a type of constraint introduced in the 2007 ORM Workshop paper "Reduction Transformations in ORM", by Halpin, Carver, and Owen, which used however an earlier notation for it). Version 22 is also the first to pull out into special, dedicated template files, the macro added in version 21 for updating fact type and object type shapes: This is to limit file-size when drawing new ORM diagrams. (Please see "How to use" section, for comments on use of these templates -- and, on easy deletion of this macro from a diagram, after using it to update shapes -- at which point it is no longer needed). 
Version 21 adds a macro that can update all the fact type and object type shapes in a (possibly earlier-version) ORM2_Draw2 diagram that is copied into an ORM2_Draw2v21 document. This will suffice to allow use of all the latest macros, on an earlier-version model. (For more-detailed instructions on using this macro, see "How to use" section.) 

Version 20 corrects a glitch, from v18, regarding the arity-changeability of the unary fact type shape. 
Version 19 implements the objectification-symbol for regular-entity-type shapes that are being used as shape-instances of a nested entity type appearing elsewhere in the diagram. (This objectification-symbol is implemented also in the NORMA tool). The symbol can be invoked from the entity type's context menu; but it is also now set (or un-set) automatically, for all entity types in the diagram, by the shadow-setting macro (available thru the shape's context menu, as well as the macro menu: see below, v14). 
Version 18 adds insertion or removal of a role at any position, in any fact type, via the roles' context menus (works only in Visio 2003 or later). Version 18 also fixes a bug from version 17, updating the O.T.-shadow-setting macro to support the new, objectified-quaternary shape. 

Version 17 adds fact-type objectification (nesting), and un-nesting of nested entity types, via their context menus; adds a new, objectified quaternary shape; improves the adjustable-arity nested fact type shape; and has a more flexible frequency constraint shape, for use as a connected note as well. Also new are a discussion of how to get Visio 2007 and 2010 to enable macros automatically that are in Visio solutions or documents in specific folders on your computer, and of how to install the solution in Visio 2010. 
Version 16 extends the nicer automatic predicate-text-positioning, to include the name-text of nested entity types; disables rotation on non-nested object types; and moves the pin (rotation-point) on "adjustable" fact-type shapes to the fact types' normal, midpoint position. 

Version 15 adds nicer automatic positioning of the predicate text upon rotation of a fact type: the text never ends up overlapping the fact-type shape; adds fact-type and object-type rotation in 90-degree increments, when rotating them via their rotation handle(s) (thanks to Dr. Roger Cass for both these great ideas!); and improves the text-parsing code used by the shadow-setting macro, making it more robust. 
Version 14 adds a Visual Basic macro (user-run) for setting the object-type shapes' shadows, and which also does a fair amount of model-checking along the way; adds automatic management of the appearance and hiding of the text arrows, as you rotate or flip a fact type; and removes the possibility of accidental, manual rotation of the fact-type text -- and of inadvertently breaking thereby the automation of that fact type's text-angle adjustment. 
Version 13 adds easy conversion from value type to entity type and vice versa; and adds automatic adjustment of the predicate text angle, when you rotate a fact type.

Version 12 overhauls the ring constraint section, increasing the number of ring constraint shapes to 26 -- thus supporting all the combinations that Dr. Halpin has identified as making logical sense, and that are currently supported by the NORMA tool; fixes a glitch with the connection points on the new link binaries; strengthens the internal structure of the fact type shapes; and makes minor improvements to the context menus of all the constraint shapes. 
Version 11 adds "link" binary fact type shapes (on which, see Halpin, T. and Morgan, T., INFORMATION MODELING AND RELATIONAL DATABASES, 2d ed., Morgan-Kaufmann, 2008, pp. 440 and ff.); improves users' ability to color fact type and role shapes; improves use of the template's macro that brings some shapes "to front" when manipulated; and moves the initial position of the deontic "o" on internal uniqueness constraints, to the end that is standard in ORM 2. 
Version 10 provides easy convertibility between preferred-identifier and non-preferred-identifier uniqueness constraints.
Version 9 fixes an issue with fact type text-arrows getting disconnected from the predicate text in Visio 12. 

Version 8 adds an external frequency constraint; supports changing the subtype link via the context menu, to being a "non-path to preferred identifier" or back to being a regular subtype link; fixes a graphical bug with the "GTE" (greater-than-or-equal-to) and "LTE" value-comparison constraints; and moves the "up" text arrow, on fact types, to the right-hand side of the text. 
Version 7 corrects another coloring problem with the single-role deontic mandatory constraints: the deontic 'o' now has its proper white fill; and improves the role-pair connector, which is now easily changed from solid to dashed and vice versa from its context menu. (For how to upgrade to the new deontic 'o' any diagrams made with v.6, see below under "Use of the new features".) 
Version 6 addresses a coloring problem when using a deontic, single-role mandatory constraint: the role-connector now stays black, while the constraint shows its proper color; and corrects the dynamic-glue anomalies on role-boxes of adjustable-arity fact types, by disabling dynamic glue on those. 

Version 5 adds easy convertibility between external-mandatory constraint, Xor constraint, and eXclusion constraint shapes; adds some useful connection-points to the adjustable-arity fact types; fixes an issue with previous-version Xor shapes (which can still cause a problem for diagrams in which they already appear: see note below under "Some additional and/or more-technical notes"); and fixes a glue problem with the binary nested fact type.
Version 4 adds greater ease and simplicity to adding/managing text arrows for predicate text.
Version 3 (ORM2_Draw2v3) adds an objectified unary, adds connection points on the subtype connector, and gives greater range on the adjustable-arity fact types. 
Version 2 (file-name ORM2_Draw2v2) improves ease of use with regard to adding, removing, and repositioning of mandatory-role constraints.   


Installation notes:
-------------------

The basic task here is that you want to identify, or to create, a folder on your computer that will hold all the Visio solutions you "install" yourself (i.e., that didn't come with your Visio, pre-installed). The complete filepath to that folder, you will then specify to Visio. Then, you also will want to identify or create appropriate SUB-folders, within that folder, to categorize your solutions; this will also make it easier to invoke them later. Let's look at the details of doing this, which depend on your Visio version and your Windows version.

For Visio 10 (2002), copy the solution, i.e. the stencil (.vss) and template (.vst) files, to the Visio 10 folder given below, probably into either its "Database" or its "Software" sub-folder. For Visio 12 (a.k.a. Visio 2007), there seems to be no standard folder for user-made templates. The "My Shapes" folder is intended for stencils, but can be adapted for broader use (on how to do that, see below). Any files you put in "C:\Program Files\Microsoft Office\Office12\1033", however, Visio 12 will definitely not find, as that folder is only for Visio-installed files.
�
If you're using Visio 12 (2007) or later, here's what we recommend: Pick out, or else create, any folder where you want to hold every SUB-folder actually holding the templates and stencils not Visio-installed. If you wish, this could well be the "My Shapes" folder (if you have one; it's usually in the "Documents" or "My Documents" folder). Or, if you have Visio 10's installed filepath for templates and stencils, you can use that--especially if it still has the templates and stencils that came with Visio 10, which you can use also in Visio 12 (as subfolder for ORM2_Draw2 stencil/template files, use the "Database" or "Software" folder). Under Windows XP, that Visio 10 installed filepath is:
�
   C:\Program Files\Microsoft Office\Visio10\1033\Solutions
�
If neither this folder nor "My Shapes" is present, or if you prefer, create any appropriate Visio-solutions folder, maybe in Documents or My Documents: maybe call it "My Visio Solutions".�

Whichever main folder you've chosen/created, now find the two filepath fields into which to copy the filepath: find them by navigating in the following way, starting from Visio's Tools menu:
�
   Tools --> Options... --> Advanced (a tab) --> File Paths... --> Stencils:
   Tools --> Options... --> Advanced (a tab) --> File Paths... --> Templates:

In Visio 2010, the fields for the filepaths are found here:

   File --> Options (a button on the left) --> Advanced (a button on the left) --> File Locations... --> Stencils:
   File --> Options (a button on the left) --> Advanced (a button on the left) --> File Locations... --> Templates:

Now type, or copy-and-paste, into both of these fields, the complete file path (including "Users\<your user name>\Documents" in Vista and Windows 7, or "Documents and Settings\<your user name>\My Documents" in XP, and up to and including at the end, the name of your main solutions folder). Again, if you're using one of the Visio 10-installed subfolder(s) such as "Database" or "Software", copy to the above two fields the above Visio 10 (2002) "Solutions" filepath. 

After saving those file-path entries and re-starting Visio, any subfolders you've placed in that main folder will always show up as solution folders, when you go to File-->New, and also�as template categories shown (listed down the left-hand side, in earlier versions -- or in Visio 2013, after you click "CATEGORIES") when you start Visio�and, also, when you�choose File-->New and click "CATEGORIES" in Visio 2013, or choose File-->New in Visio 2010, or File-->New-->Getting Started... in Visio 12 (i.e. 2007), or File-->New-->Choose Drawing Type... in Visio 10 (i.e. 2002).

    - How to make older diagrams open displaying a later stencil: 

Since every Visio diagram (.vsd) file keeps its own, internal list of stencil-files to open with it, there are two approaches to installing new versions and to keeping your old diagram-files up to date with new versions of the stencil: 

Approach 1: 
 Keep the latest stencil-version and template-version(s) under their new name. (No other versions are really needed.) Then update your diagram files individually, to link to and open the new stencil: After you open the .vsd file, close any open stencil (click on 'X' in the stencil's upper right corner), open the new stencil (go to File-->Stencils--> in Visio 10, or File-->Shapes--> in Visio 12), and then Save the .vsd file. It will thereafter open with that new stencil. Or, as an alternative,

Approach 2:
 Use the latest stencil-file to OVERWRITE the earlier version, each time a new version of it comes out; i.e. keep the version-1 stencil's filename (i.e. the one with no "v##" in it). This will make the change globally and automatically, i.e., for each .vsd file with an internal link to whichever version-1 stencil-file has that name. (The new stencil will nevertheless appear, when opened, with its correct version name at the top (e.g., "ORM2_Draw2v22"); that header is based on, not the file's name, but its "Title" as seen in its file Properties.) Discard any later-version-named template (.vst) files you receive; because they'll only make the diagram-files patterned after them call up the later-version-filenamed stencil, which in this case is redundant. 

 Instead, when following this (#2) option, use the pre-named (as version 1) template files that are included in a special, sub-zip-file included in the main download zip-file: Included in the version 3 and later zip-files, within this included zip-file, are updated versions of the version-1-named template files. Use these to overwrite any previous template files with the same filenames. So all you need to keep in the solutions folder, with this second approach, is the update of the original-version template(s), from this sub-zip-file included in the main download zip-file; and the stencil-file, which may be any version but (like the templates) has the filename of the first (and which you overwrite with each new version).
	In v25, that included folder is named "upgradedVersion1files_(YouMightNotNeedThese,seeReadMe-file,'Installation-notes')".
 
Starting with v25, one may choose to install either set of solution-files included: those for Visio 2002 file-format, and those that are of the 2003-2010 format (and thus Visio-2013-and-later compatible). If one is using Visio version 2003-2010, one might wish to install both: just keep both included folders, as separate subfolders, under the one folder whose filepath is your registered location for stencils and templates (see above).

    - To get Visio 2007 and 2010, for example, to enable macros, automatically, that are in Visio documents or solutions from specific folders:

 -- In Visio 2007, enter the filepath of your Visio solutions-folder using this menu-path:
      Tools --> Trust Center... --> Trusted Locations (a button on the left) --> Add new location... --> Browse...
       --> BE SURE TO CHECK THE BOX WHICH SAYS "Subfolders of this location are also trusted"; then click "OK".

 -- In Visio 2010, enter the filepath of your Visio solutions-folder using this menu-path:
      File --> Options (a button on the left) --> Trust Center (a button on the left) --> Trust Center Settings... --> Trusted Locations (a button on the left) --> Add new location... --> Browse...
       --> BE SURE TO CHECK THE BOX WHICH SAYS "Subfolders of this location are also trusted"; then click "OK".


How to use the new features:
----------------------------

For almost all the new features, the short answer to that question is:
    1) Right-click on the shape, and see what the context menu offers;
    2) Be aware of any control handles (little yellow diamonds) on the shape, and drag them to see what they do

For example: The built-in shadows (for fact types and object types) and text-arrows (for fact types) are revealed or hidden through using the context menu for the shape (just right-click).  The built-in connectors for the external constraints are deployed by pulling the control handles (the little yellow diamonds, in the middle) on the constraints. There are a maximum of 5 built-in connectors per constraint; but if needed you can always use the separate constraint-connector shapes.

Constraints are made deontic or alethic (the default), as well as derived or asserted (the default), by using the context menu. For the mandatory-role constraints, use the context menu of the role-connector. In version 2 and later, this menu also allows adding, removing, and repositioning of the constraint (to the other end) on the connector. 

In later versions, many of the constraint shapes were made convertible, via the context menu, into others. For example, in version 5 and later, an Xor constraint may be converted to a Mandatory or eXclusion, or vice versa, via the context menu: These shapes are now all the same, except for the setting chosen via that menu.

In version 10 and later, you can convert a non-preferred-identifier uniqueness constraint to preferred-identifier, and vice versa, via the context menu. Regarding the external-UC features new in version 22, �mixed� join-semantics setting has no effect when in �Preferred ID�r� mode; �outer-join� prevails instead. Also, the preferred-identifier uniqueness constraints were intentionally left alethic-only (per Dr. Halpin's instructions). 

If you use a dashed, "non-contiguous"-U.C. line-shape, you can change its color (for a deontic U.C.) via the context menu. In that case, remember to have the "o" (for deontic) on only one end of the U.C. (use the context menu of the other-end U.C. shape to remove the "o" from that end). 

In version 12 and later, you can use the ring constraint combinations' context menus to convert to other combinations of ring constraint. The combination-shape-sets whose members can be converted among each other are those sets whose members' base shape, respectively, is any of the following: reflexive, irreflexive, symmetric, antisymmetric/asymmetric, or acyclic/transitive/intransitive. (Play with the context menu on a few shapes, if this needs clarifying.) If you need an alethic ring constraint combined with a deontic one, use separate shapes for these. (This is the procedure one uses in NORMA also.)

Objectification of fact types is doable through their context menu in version 17 or later, as is un-nesting of nested entity types. This entails that the diagram be based, as is normal, on one of the v. 17 (or later) template files, and that its macros are enabled. (See the new discussion above, under "Installation notes", for how to get Visio 2007 and 2010 to enable macros automatically that are in Visio documents or solutions in specific folders.) 

To insert or remove a role-box at a specific position in a fact type in version 18 or later (using Visio 2003 or later), just "click through" until you have a role-box selected, either that you wish to remove or next to which you wish to insert a new role-box. Then right-click, and choose the relevant command from the context menu. (You may need then to delete or re-position some connection(s) or internal uniqueness constraint(s) whose prior connection-points were lost (by role-removal) or whose proper re-connection point(s) was indeterminate.) This feature complements, it does not replace, the fact-type-level arity-adjustment available in the "adjustable fact type" shapes.

Also on role-boxes, starting with v25, you can add rolename text. Again, just "click through" until you have the rolebox selected; then just type the text, as when you are adding predicate text to a selected fact type. The text-color will be the correct one for rolenames; but you will need to include square brackets around your rolename.
	Please note: Like all shapes in a Visio diagram, the roleboxes are always in some Z-order, i.e. back-to-front position, relative to each other, which determines which one shows in front when they are overlapping. That Z-position affects a role's rolename text as well: the Z-position of the text will be the same as that of the rolebox. But, you can easily change the role�s position in the Z-order. So, if (say) rolebox A�s text is partly hidden behind some other rolebox in the same fact type, just select role A, right-click, and choose �Bring Forward� or "Bring To Front".

To set or un-set the "objectification symbol" on a regular (i.e. non-nested) entity type shape, right-click and select it from the context menu. To have all the regular entity types' symbols set automatically, just run the shadow-setting macro (for v. 14 and later; see below), which can be run from any object type's context menu.

In version 13 and later, you can easily convert an object type shape from value type to (non-nested) entity type or vice versa, via its context menu (for which, right-click). Also in version 13 and later, there is no need ever to adjust the text-angle of a fact type, even when you rotate the fact type. (If you rotate it manually rather than thru the Action toolbar, the text angle will not change until you reach about 45 degrees, at which point the text will rotate 90 degrees. The text will always be parallel, or perpendicular, to the fact type shape, depending on the angle of the latter.) 

As of version 14, you may no longer override the automatic setting of the text-angle (via the Rotate-text button on the Action toolbar) -- for then that fact type would never thereafter have its text-angle set automatically (which was much more likely to happen accidentally than intentionally). Also in version 14, the text arrows' appearance and disappearance is handled automatically, as you rotate or flip the fact type. However, you may still add or remove the text arrow, at any time, to change the reading-direction: simply right-click and choose that option on the context menu. 

To use the version 22 (and later) two dedicated shape-update templates, follow the procedure outlined immediately below, for v21's macro, but opening in step 1 of that procedure a new Visio document of either of those two dedicated solution-types instead (either "ORM2_Draw2v24_FTsAndOTs--AutoUpgrade" or "ORM2_Draw2v24_FTsAndOTs--AutoUpgrade (US grid-units)").

Note that the n-ary fact type shapes now have extra rows of connection-points to which to glue internal U.C. shapes. For each such constraint you add, be sure to glue it to whichever unused connection-point pair is closest to the top/bottom of role-box shape.

To use the version 21 (and later) macro for updating the object types and fact types in an ORM2_Draw2 (any-version) Visio diagram, do the following:

1. Open a new Visio document of the latest solution-type (either "ORM2_Draw2v24" or "ORM2_Draw2v24 (US grid-units)").
2. Copy-and-paste into this document, whatever ORM2_Draw2 (whichever version, or hodge-podge of different versions) diagram you wish to upgrade; this can be single-page or multi-page. 
(Please note: if there are ANY ORM shapes here that are from a version prior to ORM2_Draw2 versions, the macro will not run to completion; it will abort at any point where it comes across such a shape.)
3. In this document, run the macro titled "UpdateObjAndFactTypeShapes": 
     In Visio 2010 or later, just go to Alt + F8, and select this macro for running...
     in Visio 2007 or earlier, it's easier to go thru the menu system: Tools --> Macro (or Macros) --> ThisDocument --> UpdateObjAndFactTypeShapes.
4. If the macro runs to completion, you'll get a popup message announcing this. 
5. You can then save this new Visio document to whatever new filename (which may, for example, indicate the updated status).

You might notice, after the macro runs, role-connectors which appear to be disconnected from the object type to which they should be connected. This is most likely a display issue easily fixable: just select all (Ctl + A) and hit any arrow key (left, right, up, or down) once, thus forcing Visio to re-draw. The connectors should now appear connected.

Once you have finished the above procedure, you may wish to shrink the updated model's file-size by deleting this macro from it. This is very easy to do: just go to Alt + F8, then select this macro ("ThisDocument.UpdateObjAndFactTypeShapes") from the list, and click on Delete.

Version 14 also adds a Visual Basic macro (user-run) for setting the object-type shapes' shadows, and which also does model-checking with respect to object type shapes' text. This macro can be run most conveniently from the context menu of any object type shape that is from version 14 (or later)'s stencil. Prior to v25 it may also be run, if desired, from the Macros menu (Alt + F8, or Tools --> Macros --> Macros...), by selecting "ThisDocument.CheckObjTypeShadows"; or, when filtering in that dialog so as to show only "Macros in: ThisDocument", by choosing "CheckObjTypeShadows".

There are some new aspects to that feature, starting in v25: The macro is accessible ONLY through the context menu of an object type shape (NOT from the Macros menu). At the same time, there is a useful new option in the (object types') context menu: you can choose to limit the scope of the macro, to just those object types that are on this current shape's page.

N.B.: When determining which object-type shapes are duplicate shapes of the same object type, the macro considers "This Text" and "ThisText" to be different text. Thus, one should be careful to be consistent, in representing a name or name-part as either two words or else as one word, in every shape to be treated as a duplicate of the same object type. ("This-<cr>Text", with <cr> being a carriage-return, is taken as equivalent to "ThisText".) Also for determining the duplicate object-type shapes, the macro applies the following quality checks to object-type name-text:
  1. Intra-shape quality checks:
    -- No value type shape may have any round bracket ('(' or ')') within its name text.
    -- No entity type will have more than one '(' or ')', nor a '(' without a ')' nor vice versa, nor a '(' later than a ')'.
    -- Disregarding surrounding quotation-marks or ending '!', no entity type will have text following any ')', nor lack some text (disregarding those same punctuation marks) before any '('.
    -- No entity type will have empty reference mode (following any initial '.' or before any ending ':').
    -- Disregarding surrounding quotation-marks or ending '!', no object type will have no name-text. 
  2. Inter-shape quality checks:
    -- No value type will have the same object-type name as an entity type.
    -- Two entity types with the same name must also have the same reference mode, or else both have no reference mode.
    -- Two object types with the same name must also have the same independence status (i.e., must both be independent or both be non-independent).
    -- A non-nested entity-type shape can have the same entity-type name (and thus represent the same entity type) as a nested entity type shape; but...
       ...two nested entity-type shapes with the same entity-type name must have the same number of roles.
    -- Comparison of names and reference modes is case-insensitive...
       ...but as mentioned, it is white-space sensitive: so best be consistent in use (or non-use) of whitespace in object type names...
       ...(again, use a hyphen before carriage-return if you wish not to have the carriage-return interpreted as a white space).
An object-type shape violating any of these rules will cause the macro to present an appropriate error message to the user and to terminate. If the macro finds no such errors, it sets the object-type shadows and then reports the run as successful.

The "pair-connector" shape glues, on each end, to the connection-points on the role-box. In version 7 and later, right-click on it and use the context menu to change the line-pattern from solid to dashed or vice versa.

In version 8 and later, use the subtype connector's context menu to change it from being a "path to preferred identifier" to being a "non-path" to preferred identifier, or vice versa.

In version 11 and later, there are "link binary" fact type shapes (on which, see Halpin, T. and Morgan, T., INFORMATION MODELING AND RELATIONAL DATABASES, 2d ed., Morgan-Kaufmann, 2008, pp. 440 and ff.). "Link" fact types are the implied, "virtual" fact types that each connect a nested entity type with one of the object types playing a role in that nested fact type. (There is one "link" binary for each role in the nested, i.e. objectified fact type.) The displaying of such implied fact types is sometimes advantageous in that it may allow the graphical display of some constraint that applies to such a fact type and that would otherwise have to be expressed textually. Graphical display of link fact types also helps one visualize navigation paths for derivation rules and constraints that involve link fact types.

When using these "link" binary fact type shapes, remember that the role in it connected to the nested entity type should be mandatory and unique. Also note this, from p. 440 of the above textbook: "If the modeler does not supply readings for the linking predicates, default predicate readings are assigned, such as 'involves', appended by numbers if needed to distinguish linking fact types that link back to the same object type (which plays more than one role in the fact type being objectified). "

Version 15's new features are automatic: When rotating a fact type or object type (including nested entity type) by its rotation handle(s), the shape will not appear to be rotating until one moves the handle past a 45-degree angle, at which point the shape will rotate 90 degrees. Thus the shape is always vertical or horizontal, there's no chance of leaving it at an off angle. Version 16's new features are also automatic.

The v. 17 improvement to the nested, adjustable-arity fact type shape is that you can now do "horizontal" (i.e. end-to-end) flipping of the fact type shape within the entity type (as was already doable on other nested fact type shapes). The width of text-box in the internal-frequency-constraint shape can be adjusted now, by dragging either of its side selection handles (when the shape is selected). Within the box, text will word-wrap.

The Table-shape's nr. of columns and nr. of rows, as well as the arity of the adjustable-arity fact type shapes, are each set as a custom property of the shape. The dialog box for setting it comes up automatically when you drag the shape onto the diagram. To recall the dialog afterwards, right-click on the shape and consult the context menu. To resize the width of the Table's columns, select the column, then drag the control-handle (the little yellow diamond) on its right side.


Some unavoidable anomalies, and work-arounds for them
-----------------------------------------------------

    - Connecting a role-connector to a nested entity type:

This uses the "dynamic glue" of the nested entity type -- just as with a non-nested object type shape. However, the magnification in Visio generally needs to be up pretty high in order to glue the connector to a nested entity type. We recommend that you bump the magnification up to 300x or so, in Visio, to do gluing to such shapes.

    - Adding newer single-mandatory-constraint dots to diagrams from older versions:

This is NOT simply a matter of dragging over a newer-version role-connector, and invoking whatever dot you want (alethic or deontic, asserted or derived) via the context menu. This kind of constraint shape uses Visio's custom-line-end feature: and custom line-ends dwell "under the covers" in the diagram file, not in the shape itself. 

And if your diagram is based on no ORM2_Draw2 template, or on a template from an ORM2_Draw2 version earlier than the mandatory-role dot (line-end) you want, the diagram file will not naturally contain that role-dot. If you have a shape trying to invoke a custom Line-End that doesn't exist within the document, the line-end won't appear.

However, another peculiarity affords us a work-around: If you have in your stencil a shape that is displaying such a custom line-end, then when you drag that shape onto a Visio drawing, that shape's custom line-end will also be conveyed into the latter drawing file. It will then be available for use by any of the (newer) connector shapes you put in that file.

So, the work-around is to drag over at least one role-connector that does show the particular dot-style you want. (This was the point in having every single-mandatory-role dot-style show explicitly in the stencil: alethic or deontic, and derived or asserted.) This mandatory-role-dot issue is another reason we recommend that, when starting any ORM2_Draw2 diagram, you always base it on the latest appropriate ORM2_Draw2 template (i.e., select your desired ORM2_Draw2 Visio new-file type -- from the "File --> New" menu or from the start-up display).

After dragging the new Line End over, you will not immediately see the dot appear on connector-lines that are already invoking it in your drawing. To make it show up, you can just hit Ctrl+A, to select all the shapes, and then hit an arrow-button; that will give all the shapes a "nudge", causing Visio to re-draw them. The dot will immediately appear on any connectors invoking it.

If you wish to see what custom Line Ends are available for a shape to use, in any VSD file you have opened, just open the Drawing Explorer Window (in Visio 2007 go to View --> Drawing Explorer Window) and look thru the folders there -- the last one, usually, will be named "Line Ends". (To see the actual custom line-end, right-click on its name in that folder, then choose "Edit Pattern" or "Edit Pattern Shape" -- but don't actually edit the shape that appears! After viewing it, simply close its window.)

To upgrade v.6 diagrams to support the new, v.7 (and later) deontic 'o' on the single-mandatory-role constraints: first, open the diagram, allow the macro ("active") content, then close the v.6 stencil, and open the v.7 stencil (File --> Shapes , in Visio 12). Take note of any deontic mandatory constraints in the diagram. Then, open the Drawing Explorer window (View --> Drawing Explorer Window). In that window, un-collapse the "Line Ends" folder, then right-click on any "MandDot.160" line-end and delete it (answer 'OK' when asked about it). Then, drag over from the stencil the role-connector shape that is already showing the deontic mandatory constraint. (A new "MandDot.160" line-end will now appear in the Explorer window.) Now delete that shape and save the diagram (Ctl+S). This will convert the diagram to allow the new deontic 'o', and allow any v.6 deontic mandatory role constraints you had showing in it to be re-set as v.7 ones -- which requires only forcing Visio to re-draw, by, for example, hitting Ctrl+A to select all the shapes and then hitting any of the arrow-buttons.

    - Using Visio 10 diagrams in Visio 11 and later, and vice versa:

The cause of the APPARENTLY�-but not actually�-disconnected role-connectors when you open a Visio 10 ORM diagram in Visio 12 or later, has in reality nothing to do with connectors or glue. What's happening is just that the object types are drawn wider in Visio 12 and later, due to the text block having a built-in extra space character on every line, and the object types� width being based on the text-width (including that extra space). The reverse problem occurs also, when you open a Visio 11 or 12 or later diagram in Visio 10.

The good news is there's an easy work-around: After you've opened the Visio 10 diagram in Visio 12 or later (or vice versa), just press Ctl-A to select everything in the diagram, then nudge the diagram with one press of an arrow key in any direction. This forces Visio to re-draw. All the connectors will immediately APPEAR to reconnect to the object types--due to the still-attached glue of the connector.

N.B.: As of Visio 2013, the old Visio 2002 file format is no longer really supported; for example, there are issues with copy-and-paste into Word or PowerPoint from the older-format diagrams. In some installations of 2013 or later, registry settings may actually prevent starting a diagram-file based on the older-file-format ORM2_Draw2 solution. 

So, starting in v25 we include a set of files for each of the Visio file-formats. (We had previously been keeping our stencil and template files in the older format for backward compatibility with Visio 2002.) If you are using 2013 or later, but have some older ORM2_Draw2 diagrams you still want to copy-and-paste from without diagram glitches, just copy and paste those older diagrams into into a new v25 diagram-file. The diagram will copy-and-paste from there without glitches; you should save that file, as a Visio 2003-2010 .VSD file -- or, in any newer, Visio 2013 format you prefer.

    - A problem caused by having earlier-version Xor shapes in a diagram:

You might find strange behavior of later-version Xor shapes when you drag them into a diagram in which there have already been earlier-than-version-5 ORM2_Draw2 or ORM2_Draw Xor shapes: the later-version shape will convert to the earlier-version Xor, immediately when dropped on the drawing pane! This surprising behavior is caused by a property setting on earlier-version Xor shapes. Deleting them from the older diagram will not get rid of the problem, however: you will find that the diagram file itself seems to have been infected with the older-version Xor, and will continue to convert newer-version Xor's.

Here's how to fix this seeming "infection" in a diagram file that has had older-version Xor's in it: In the menu system, go to View --> Drawing Explorer Window (unless that window is already in view), and in that window, un-collapse the folder named "Masters". Right-click on the icon for the "Xor" master shape, and from its context menu either delete it, or go to "Master Properties..."; then, if you're in the latter menu, un-check the check-box for "Match master by name on drop" and click on "OK". After that there will be no more automatic retro-versioning of Xor shapes dropped on that diagram.


Some additional and/or more-technical notes:
--------------------------------------------

    - The table-shape problem:

ORM2_Draw, the earlier ORM2 drawing stencil for Visio, was developed using Visio 10. It included a �Table� shape, quite convenient for showing sample fact-populations. This shape had been based on the Table shape which Visio 10 supplies in its �Charting Shapes� stencil (in the �Forms and Charts� solution-folder). Both shapes make extensive use of some Automation, implemented in the form of a �Visio add-on� held in two files: VisTable.vsl and VisTable.dll.

The Automation for the shape does not operate at all in Visio 12-�except under the odd condition that the Visio version previously started most recently, on the same computer, was Visio 10. (This peculiarity was replicable on a machine which used Windows XP Pro; we haven�t tested it on a machine which uses Windows Vista.) Thus, neither the configurations nor the column-sizes of tables entered in Visio 10 are adjustable in Visio 12, and the Table shape itself cannot be dropped from a stencil onto a diagram in Visio 12. 

The shape itself has in fact been replaced with a less functional �Grid� shape in Visio 11 and 12. The Grid is not an adequate substitute for the Table, though -- at least not for ORM sample-fact tables, due to the inability to adjust the widths of columns individually.

As it turned out, there were enough pieces of the puzzle discernible from an examination of the original Table shape and the Grid substitute, to discover how to build an adequate table shape without using Automation: The Grid shape, for example, uses Custom Properties, rather than Automation, to allow the user to choose the number of rows and columns in the table�-the drawback being that one must fix, at design time, the maximum numbers of rows and of columns available.

    - The template files (there be macros here...):

There are several macros residing in the template (.vst) files. The first two use, respectively, a VB function to send an object to the back, and one to bring it to the front. 
 
Here are the only places where one of these macros is called from the stencil's shapes: Whenever one of the mandatory-role connectors is moved at either or both ends, it is brought to the front. This is so that the mandatory-role dot will always automatically appear in front of the role-box or object type it's connected to--even when it was dragged from the stencil before the object/fact type was.
 
Also, the internal uniqueness constraints, the subtype connector, and the role-"pair connector" call up the template-macro that brings them to the front whenever they're moved. This would normally be noticeable only when you're using them on objectified fact types. As of verson 11, the same applies to external constraints: they are brought to the front whenever one of their built-in connectors moves.
 
Each of these two macros contains exactly one line of code: one of the above is all they do. So they're perfectly safe. 

Also, from version 14 onwards, there is a macro for setting of object-type shadows (see above for a description). This macro is perfectly safe also, as it manipulates only the shadow properties of shapes on the diagram. The code for any of these macros may be examined by invoking the Visual Basic editor in Visio (Alt + F11). There one will find five other functions / subroutines that are used by the macro: their names and the macro's dependencies on them are shown in this graph (which shows up best when using a monospace font, e.g. Courier):

               (our macro:) CheckObjTypeShadows --> ParseOTtext2 --+--> NormalizeWhtSpc
                                             |            |        +----------
                                             |            |        V         |
                                             V            + <-- TrimOTtext   V
                                            GoToShape <---+ <------ TrimRefMode

From version 17 and onwards, there is a macro to Objectify a fact type, and one to UnObjectify a nested entity type (see above). From version 18 and onwards, there is a macro to "ChangeArity" of a non-nested fact type, and one to "ChangeArityObj", i.e. to change arity of a nested fact type (see above). Version 21 introduces a macro that can update all the fact type and object type shapes in (possibly earlier-version) ORM2_Draw2 diagram that is copied into an ORM2_Draw2v21 document. In version 22, this macro is separated out into special template files dedicated to such updating.

It is strongly advised to "enable macros" when starting a solution based on either template file. (See the new discussion above, under "Installation", for how to get Visio 2007 and 2010 to enable macros automatically that are in Visio documents or solutions in specific folders.) On the other hand, you don't have to enable them in order to use the stencil. Nor is it absolutely necessary to use the template in order to use the stencil; but you will lose the functionalities that depend on one or more of these macros. The only other relevant feature of the template files, besides the above macros, is that they bypass the role-connector problem mentioned above (see the above section "Some unavoidable use-anomalies, and work-arounds for them").

Last revised: 9 November 2016

